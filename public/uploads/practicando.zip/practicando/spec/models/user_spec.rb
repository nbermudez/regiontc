require 'spec_helper'

describe User do
	before (:each) do
		@att = {:name => 'Nestor Bermudez', :email => 'nestor.bermudez@unitec.edu', 
			:password => 'patito', :password_confirmation => 'patito'}
	end

	it 'Valido la presencia de nombre' do
		user = User.new ({:name=>'', :email =>'hola@unitec.edu'})
		user.should_not be_valid
	end

	it 'Valido la presencia del email' do
		user = User.new ({:name=>'Nestor', :email =>''})
		user.should_not be_valid
	end
	
	it 'Valido que el email sea unico' do
		user = User.new (@att.merge(:name => 'Andrea'))
		user.save
		user1 = User.new (@att)
		user1.should_not be_valid
	end
	
	it 'Valido que pida una contrasena' do
		user = User.new (@att.merge(:password => '', :password_confirmation => ''))
		user.should_not be_valid
	end

	it 'Valido que las contrasenas sean iguales' do
		user = User.new (@att.merge(:password => 'patito', :password_confirmation => 'nopatito'))
		user.should_not be_valid
	end
  
end
