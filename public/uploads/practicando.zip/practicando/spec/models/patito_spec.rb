require 'spec_helper'

describe Patito do
  it 'Esto deberia fallar xD' do
  	patito=Patito.new
  end

  it "deberia ser igual" do
  	5.should eql(5)
  end

  it "deberia ser mayor" do
  	4.should be > 5
  end

  it "debe ser de tipo string" do
  	"patito".should be_instance_of(String)
  end

  it "no debe ser de tipo string" do
  	7.should_not be_instance_of(String)
  end

  it "debe ser nil" do
	nil.should be_nil
  end


end
