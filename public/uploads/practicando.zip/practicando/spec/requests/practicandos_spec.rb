require 'spec_helper'

describe "Practicandos" do
 
end
