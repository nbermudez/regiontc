class Patito < ActiveRecord::Base
  attr_accessible :name
end
