class CreatePatitos < ActiveRecord::Migration
  def change
    create_table :patitos do |t|
      t.string :name

      t.timestamps
    end
  end
end
